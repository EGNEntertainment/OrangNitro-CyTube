# Bill's Custom CyTube Theme
The git for my cytube theme, it's a mess so just contact me on CyTube if you want to use it :)
You can usually find me over at https://cytu.be/r/southparkhd

# Issues
If you want to help me out fixing some bugs, feel free to help me out :)

1. html5 player stops working / hangs randomly.
2. Can't get chromecast to stream the proper div.
